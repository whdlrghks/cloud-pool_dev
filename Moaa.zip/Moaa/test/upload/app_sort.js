var name = "";
//
// function test(){
//   name = "Irene/test/test";
//   var arr = name.split("/");
//   console.log(name);
//   console.log(arr[arr.length-1]);
// };
// test();
var test  = [];
test.push("wer");
// test.push("rtw");
// test.push("wertq");

console.log(test.toString());
var test3 =test.toString().split(",");
console.log(test3);
// var present = new Date();
// console.log(present.toLocaleString()
//         );
// console.log(new Date().toISOString().
//   replace(/T/, ' ').      // replace T with a space
//   replace(/\..+/, ''));

// var size = ["G:2","B:15132","D:1232"];
// var size_array=[];
// var totalsize=0;
// for(var i = 0 ; i<size.length;i++){
//   size_array[i]=parseInt(size[i].split(":")[1]);
//   totalsize= totalsize+size_array[i];
// }
// var pos_num = [];
// for ( var n = 0 ; n < size_array.length; n++){
//       console.log(size_array[n]/3);
//       pos_num[n] = parseInt(size_array[n]/3);
// }
// console.log(size_array);
// // console.log(totalsize);
// console.log(pos_num);
// console.log(size_array.indexOf('S'));
// console.log(size);
// var size_sort =JSON.parse(JSON.stringify( size_array ));
// var flag=0;
// var num=0;
// switch (flag) {
//           case 0:
//             flag=1;
//             console.log(0);
//             if(true){
//               console.log("qwe");
//               num=num+1;
//               break;
//             }
// console.log("51243");
//           case 1:
//             flag=2;
//             console.log(1);
//             num=num+1;
// break;
//           case 2:
//             flag=0;
//             console.log(2);
//             num=num+1;
//
//             if(num>6){
//               console.log("finish");
//               break;
//             }
//
//         }
// // console.log(size_sort.indexOf(size_array.sort()[2]));
