var Long = require('long');

var num=Long.fromNumber(16377128 / 3)
console.log(Long.fromValue(16377128 / 3));
